# install.packages("https://cran.r-project.org/src/contrib/Archive/rlang/rlang_1.0.5.tar.gz", repos = NULL, type="source")

install.packages("ggvis")
install.packages("shinycssloaders")
devtools::install_github("mattflor/chorddiag")
library(shiny)
library(ggvis)
library(chorddiag)
library(shinyBS)
library(shinycssloaders)

dat <- read.csv(file = "baseR_file.csv", sep = ",", header = TRUE, row.names = 1)
dim(dat)

use_donors <- rownames(dat)


# Define UI ----
ui <- fluidPage(
  tags$head(
    includeCSS("./www/style.css")
  ),
  HTML("<h3>Gene Expression Analysis of Breast Cancer</h3>"),
  HTML('<center><img src="Nanoparticle-illustration.gif" width = "800"></center>'),
  HTML("<p>Breast cancer is the most common cancer in women in Australia (apart from non-melanoma skin cancer) and the second most common cancer to cause death in women, after lung cancer.

Breast cancer is the abnormal growth of the cells lining the breast lobules or ducts. It is estimated that 19,866 women and 164 men in Australia will be diagnosed with breast cancer in 2021.

In Australia, the overall five year survival rate for breast cancer in females is 91%. If the cancer is limited to the breast, 96% of patients will be alive five years after diagnosis; this figure excludes those who die from other diseases. If the cancer has spread to the regional lymph nodes, five year relative survival drops to 80%.</p>"),
  HTML("<p>The development of gene microarray techniques has enabled scientists to detect the differences of gene expression among thousands of genes simultaneously and thus create gene expression profiles for different types of breast cancer.</p>"),
  tabsetPanel(
    tabPanel(
      title = "Genes Information",
      div(
        id = "app_info", p("This visualisation is based on Identification of five cytotoxicity-related genes involved in the progression of breast cancer:"),
        tags$a(href = "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE183947", "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE183947"),
        p(""),
        p("Breast cancer is one of the deadly tumors in women, and its incidence continues to increase. This study aimed to identify novel therapeutic molecules using RNA sequencing (RNAseq) data of breast cancer from our hospitals."),
        p("30 pairs of normal and cancerous tissues from the same excision were collected from the Affiliated Cancer Hospital of Guangzhou Medical University, the Affiliated Cancer Hospital of Sun Yat-sen University and Guangzhou Army General Hospital. RNA sequencing was performed by Guangzhou Huayin Health medical Group. Original reads of RNA sequencing data were normalized as FPKM data."),
      ), class = "span7"
    ),
    # Genes Responsible for Breast cancer ui components
    tabPanel(
      title = "Genes Responsible for cancer",
      fluidRow(
        column(
          12, br(),
          shinyjs::useShinyjs(),
          div(id = "genes_div"),
          div(id = "transcripts_div"),
          div(id = "clinvar_div"),
          h2("Gene Responsible for breast cancer"),
          p("PCA which is a Principal Component Analysis is used here to find the genes that are responsible for breast cancer cells, This is a dimensionality reduction technique used to improve the interpretability of a given
dataset by minimizing information loss and maximizing variance


"),
          p(""),
          sliderInput("range", "Select Number of genes to visualize:", min = 1, max = 5000, value = c(45, 100)),
          plotOutput(outputId = "pca", height = 600, width = 400) %>% withSpinner(color = "#0dc5c1")
        )
      )
    ),
    tabPanel(
      title = "Co-relation Between Genes",
      fluidRow(
        fluidRow(
          column(
            12, br(),
            shinyjs::useShinyjs(),
            div(id = "genes_div"),
            div(id = "transcripts_div"),
            div(id = "clinvar_div"),
            h2("Co-relation Between Genes:"),
            selectInput("genes", "Please Select the genes:",
              choices = NULL, selected = NULL,
              multiple = TRUE
            )
          ),
          chorddiagOutput("distPlot", height = 600) %>% withSpinner(color = "#0dc5c1"),

          # plotOutput(outputId = "plots")
        )
      ), class = "span7"
    ),
    tabPanel(
      title = "Metastasis Distribution of genes",
      fluidRow(
        column(
          12, br(),
          shinyjs::useShinyjs(),
          div(id = "genes_div"),
          div(id = "transcripts_div"),
          div(id = "clinvar_div"),
          h2("Metastasis distribution in genes"),
          selectInput("genes_list", "Please Select the genes:",
            choices = use_donors, selected = "BRCA1",
            multiple = FALSE
          ),
          plotOutput(outputId = "pca1", height = 600, width = 400) %>% withSpinner(color = "#0dc5c1"),
          plotOutput(outputId = "pca2", height = 600, width = 400) %>% withSpinner(color = "#0dc5c1")
        )
      )
    )
  )
)

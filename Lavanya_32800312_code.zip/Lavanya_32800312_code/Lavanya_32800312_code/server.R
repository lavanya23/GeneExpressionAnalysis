devtools::install_github("mattflor/chorddiag")
BiocManager::install(c("DESeq2", "GEOquery", "canvasXpress", "ggplot2", "clinfun", "GGally", "factoextra", "glmpca"),force=TRUE)
install.packages("dplyr")
install.packages("tidyverse")
install.packages("GGally")
install.packages("igraph")
install.packages("shinyBS")
install.packages("shinyjs")

library(shiny)
library(ggvis)
library(dplyr)
library(chorddiag)
library(tidyverse)
library(igraph)
library(GEOquery)
library(ggplot2)
library(GGally)
library(shinyBS)
library(shinyjs)
library("factoextra")

dat <- read.csv(file = "baseR_file.csv", sep = ",", header = TRUE, row.names = 1)
dim(dat)

# get metadata --------
gse <- getGEO(GEO = "GSE183947", GSEMatrix = TRUE)
gse
metadata <- pData(phenoData(gse[[1]]))

head(metadata)

metadata.modified <- metadata %>%
  select(1, 10, 11, 17) %>%
  rename(tissue = characteristics_ch1) %>%
  rename(metastasis = characteristics_ch1.1) %>%
  mutate(tissue = gsub("tissue: ", "", tissue)) %>%
  mutate(metastasis = gsub("metastasis: ", "", metastasis))


raw_counts <- as.matrix(dat)
rownames(metadata.modified) <- metadata.modified$description

all(rownames(metadata.modified) %in% colnames(raw_counts))

# the outcome should be TRUE

all(colnames(raw_counts) %in% rownames(metadata.modified))

metadata.modified$tissue <- as.factor(metadata.modified$tissue)
metadata.modified$metastasis <- as.factor(metadata.modified$metastasis)


test <- as.matrix(dat[1:3, ])

use_genes <- rownames(dat)
use_genes_list <- rownames(dat)

server <- function(input, output, session) {
  updateSelectizeInput(session, "genes", choices = use_genes, server = TRUE, selected = "BRCA1")

  observe({
    if (!is.null(input$genes_list)) {
      print(input$genes_list)
    }
    # updateSelectizeInput(session, 'genes_list', choices = use_genes,selected = "BRCA1")
  })

# ChordPlot
  output$distPlot <- renderChorddiag({
    rnorm(1:100000)

    chorddiag(as.matrix(dat[input$genes, ]),
      type = "bipartite", showTicks = F, groupnameFontsize = 14, groupnamePadding = 10, margin = 90,
      clickAction = "Shiny.onInputChange('sourceIndex', d.source.index+1);
                                 Shiny.onInputChange('targetIndex', d.target.index+1);",
      clickGroupAction = "Shiny.onInputChange('groupIndex', d.index+1);"
    )
  })

  #Co-relation Plot

  output$plots <- renderPlot(
    {
      rnorm(1:100000)
      pairwise_corr <- ggpairs(as.data.frame(log2(t(dat))),
        columns = input$genes,
        upper = list(
          continuous = wrap("cor",
            method = "spearman", size = 3
          ),
          combo = "box_no_facet",
          discrete = "count",
          na = "na"
        ),
        ggplot2::aes(
          colour = metadata.modified$tissue,
          shape = metadata.modified$tissue, alpha = 0.01
        )
      )
      pairwise_corr <- pairwise_corr + theme(
        strip.placement = "outside",
        text = element_text(size = 9, face = "bold")
      ) +
        ggtitle("Gene correlation") +
        theme(plot.title = element_text(size = 15, hjust = 0.5)) +
        ylab("log2(counts +1)") +
        xlab("log2 (counts +1)")
      pairwise_corr
    },
    height = 300,
    width = 500
  )

  #density Map for Corelation

  output$plotsSingle <- renderPlot(
    {
      rnorm(1:100000)
      MX1 <- ggplot(NULL, aes(
        x = metadata.modified$tissue,
        y = log2(t(dat[input$genes[input$groupIndex], ]))
      )) +
        geom_jitter(aes(
          shape = metadata.modified$tissue,
          color = metadata.modified$tissue
        ), size = 3) +
        xlab(NULL) +
        ylab(paste0(input$genes[input$groupIndex], "expression \n log2 (norm counts +1)")) +
        theme(legend.position = "bottom") +
        theme_bw() +
        theme(
          axis.text = element_text(size = 15),
          axis.title = element_text(size = 15),
          plot.title = element_text(size = 25),
          legend.position = "none"
        ) +
        stat_summary(
          fun = mean,
          geom = "point",
          shape = "_",
          size = 14,
          colour = c("#b53d35", "#066e70")
        )

      MX1
    },
    height = 300,
    width = 500
  )

# PCA Plot
  output$pca <- renderPlot(
    {
      rnorm(1:100000)
      res.pca <- prcomp(t(log2(dat[c(input$range[1]:input$range[2]), ])),
        scale = TRUE
      )

      # replace gene1, gene2, geneN by the list of genes of your interest

      res.pca

      p <- fviz_pca_biplot(res.pca,
        col.ind = metadata.modified$tissue,
        geom = "point",
        addEllipses = TRUE,
        palette = c("#F8766D", "#00BFC4"),
        title = "Principal Component Analysis"
      )
      p
    },
    height = 600,
    width = 600
  )

#Metasis Distribution
  output$pca1 <- renderPlot(
    {
      rnorm(1:100000)

      MX2 <- ggplot(NULL, aes(
        x = metadata.modified$metastasis,
        y = log2(t(dat[input$genes_list, ]))
      )) +
        geom_boxplot(aes(
          shape = metadata.modified$metatasis,
          color = metadata.modified$metatasis
        ), size = 3) +
        xlab(NULL) +
        ylab(paste0(input$genes_list, " expression metastasis  log2 (norm counts +1)")) +
        theme(legend.position = "bottom") +
        theme_bw() +
        theme(
          axis.text = element_text(size = 15),
          axis.title = element_text(size = 15),
          plot.title = element_text(size = 25),
          legend.position = "none"
        ) +
        stat_summary(
          fun = mean,
          geom = "point",
          shape = "_",
          size = 14,
          colour = c("#b53d35", "#066e70")
        )

      MX2
    },
    height = 600,
    width = 600
  )

#Metastasis distribution density plot
  output$pca2 <- renderPlot(
    {
      rnorm(1:100000)
      pairwise_cor <- ggpairs(as.data.frame(log2(t(dat))),
        columns = input$genes_list,
        upper = list(
          continuous = wrap("cor",
            method = "spearman", size = 3
          ),
          combo = "box_no_facet",
          discrete = "count",
          na = "na"
        ),
        ggplot2::aes(
          colour = metadata.modified$tissue,
          shape = metadata.modified$metatasis, alpha = 0.01
        )
      )
      pairwise_cors <- pairwise_cor + theme(
        strip.placement = "outside",
        text = element_text(size = 9, face = "bold")
      ) +
        ggtitle("Gene distribution Based on Metatasis") +
        theme(plot.title = element_text(size = 15, hjust = 0.5)) +
        ylab("log2(counts +1)") +
        xlab("log2 (counts +1)")
      pairwise_cors
    },
    height = 600,
    width = 600
  )

# Spearment Density Map popup modal
  observeEvent(input$targetIndex,
    {
      rnorm(1:100000)
      showModal(div(id = "modalAutoSaveMenu", modalDialog(
        inputId = "distPlot",
        title = HTML('<span style="color:#339fff; font-size: 20px; font-weight:bold; font-family:sans-serif ">Gene Co-relation<span>
                     <button type = "button" class="close" data-dismiss="modal" ">
                     <span style="color:#339fff; ">x <span>
                     </button> '),
        br(),
        plotOutput("plots"),
        br(),
        easyClose = TRUE,
        footer = NULL
      )))
    },
    once = FALSE
  )

# Popup Modal for group
  observeEvent(input$groupIndex,
    {
      rnorm(1:100000)
      showModal(div(id = "modalAutoSaveMenu", modalDialog(
        inputId = "distPlot",
        title = HTML('<span style="color:#339fff; font-size: 20px; font-weight:bold; font-family:sans-serif ">Gene Expression value distributed over Normal Samples and Breast Samples<span>
                     <button type = "button" class="close" data-dismiss="modal" ">
                     <span style="color:#339fff; ">x <span>
                     </button> '),
        br(),
        plotOutput("plotsSingle"),
        br(),
        easyClose = TRUE,
        footer = NULL
      )))
    },
    once = FALSE
  )
}
